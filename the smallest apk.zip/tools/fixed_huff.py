import struct, zlib, subprocess, os, tempfile

def fixed_lit(lit):
    if lit <= 143: return (0x30 + lit, 8)
    if lit <= 255: return (0x190 + lit - 144, 9)
    if lit <= 279: return (lit - 256, 7)
    return (0xC0 + lit - 280, 8)

LEN_TABLE = [
    (257, 3, 0, 0), (258, 4, 0, 0), (259, 5, 0, 0), (260, 6, 0, 0),
    (261, 7, 0, 0), (262, 8, 0, 0), (263, 9, 0, 0), (264, 10, 0, 0),
    (265, 11, 1, 0), (266, 13, 1, 0), (267, 15, 1, 0), (268, 17, 1, 0),
    (269, 19, 2, 0), (270, 23, 2, 0), (271, 27, 2, 0), (272, 31, 2, 0),
    (273, 35, 3, 0), (274, 43, 3, 0), (275, 51, 3, 0), (276, 59, 3, 0),
    (277, 67, 4, 0), (278, 83, 4, 0), (279, 99, 4, 0), (280, 115, 4, 0),
    (281, 131, 5, 0), (282, 163, 5, 0), (283, 195, 5, 0), (284, 227, 5, 0),
    (285, 258, 0, 0),
]

def get_len(length):
    for code, base, extra, _ in LEN_TABLE:
        if code == 285: continue
        # 从后往前找：找最接近的 base <= length
    # 简化：暴力匹配
    best = None
    for i, (code, base, extra, _) in enumerate(LEN_TABLE[:-1]):
        next_base = LEN_TABLE[i+1][1] if i+1 < len(LEN_TABLE)-1 else 259
        if base <= length < next_base:
            return (code, extra, length - base)
    return (285, 0, 0)

DIST_TABLE = [
    (0, 1, 0), (1, 2, 0), (2, 3, 0), (3, 4, 0),
    (4, 5, 1), (5, 7, 1), (6, 9, 1), (7, 13, 1),
    (8, 17, 2), (9, 25, 2), (10, 33, 2), (11, 49, 2),
    (12, 65, 3), (13, 97, 3), (14, 129, 3), (15, 193, 3),
    (16, 257, 4), (17, 385, 4), (18, 513, 4), (19, 769, 4),
    (20, 1025, 5), (21, 1537, 5), (22, 2049, 5), (23, 3073, 5),
    (24, 4097, 6), (25, 6145, 6), (26, 8193, 6), (27, 12289, 6),
    (28, 16385, 7), (29, 24577, 7),
]

def get_dist(dist):
    for i, (code, base, extra) in enumerate(DIST_TABLE):
        limit = DIST_TABLE[i+1][1] if i+1 < len(DIST_TABLE) else 32769
        if base <= dist < limit:
            return (code, extra, dist - base)
    return (29, 7, dist - 24577)

def encode_fixed(data):
    bits = []
    def emit(v, n):
        for i in range(n-1, -1, -1):
            bits.append((v >> i) & 1)
    def emit_lit(l):
        c, n = fixed_lit(l)
        emit(c, n)
    emit(1, 1)  # BFINAL
    emit(1, 2)  # BTYPE=01 (fixed huffman)
    pos = 0
    n = len(data)
    while pos < n:
        best_len, best_dist = 0, 0
        start_min = max(0, pos - 4096)
        for start in range(start_min, pos):
            l = 0
            max_l = min(258, n - pos)
            while l < max_l and data[start+l] == data[pos+l]:
                l += 1
            if l > best_len:
                best_len, best_dist = l, pos - start
        if best_len >= 3:
            lc, le, lv = get_len(best_len)
            emit_lit(lc)
            if le: emit(lv, le)
            dc, de, dv = get_dist(best_dist)
            emit(dc, 5)
            if de: emit(dv, de)
            pos += best_len
        else:
            emit_lit(data[pos])
            pos += 1
    emit_lit(256)
    while len(bits) % 8: bits.append(0)
    out = bytearray()
    for i in range(0, len(bits), 8):
        b = 0
        for j in range(8): b = (b << 1) | bits[i+j]
        out.append(b)
    return bytes(out)

if __name__ == '__main__':
    for fn in ['AndroidManifest.xml', 'META-INF/MANIFEST.MF', 'E.SF', 'E.EC']:
        if not os.path.exists(fn): continue
        data = open(fn,'rb').read()
        with tempfile.NamedTemporaryFile(delete=False) as tf:
            tf.write(data); tmp = tf.name
        r = subprocess.run(['zopfli','--deflate','--i1000','-c',tmp], capture_output=True)
        z = r.stdout
        os.unlink(tmp)
        fh = encode_fixed(data)
        print(f'{fn:25s} raw={len(data):4d} zopfli={len(z):4d} fixed={len(fh):4d}')
