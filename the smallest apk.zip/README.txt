English introducation after Chinese 
# 最小 APK 探索记录

## 三个最终成品

| 目录 | 文件 | 大小 | 支持范围 |
|---|---|---|---|
| Android1.0+/ | final_1111.apk | 1111B | Android 1.0 - 16 |
| Android4.2+/ | final_1064.apk | 1064B | Android 4.2 - 16 |
| Android7.0+/ | final_776.apk | 768B | Android 7.0 - 16 |

三个都在 Android 16 手机上验证能装。

## 核心突破

### v2 路径（768B）

1. **改 apksig 源码去 4K 对齐**：修改 ApkSigner.class 和 ApkSigningBlockUtils.class 里的字节码常量 4096 → 1，去掉 3955B padding
2. **逆向 apksig 的 chunked_sha256 算法**：
   - 3 个独立数据源（local + central dir + EOCD）
   - 每个 chunk = SHA256(0xa5 + u32(len) + data)
   - 最终 = SHA256(0x5a + u32(3) + chunk0 + chunk1 + chunk2)
3. **手工构造 v2 签名块**：绕过 apksig 生成更紧凑的 PKCS#7 结构
4. **证书精简**：剥离 version/SKI/AKI/BasicConstraints，序列号改 1
5. **签名撞短**：ECDSA 签名长度随机（68/69/70/71/72B），反复重签撞到最小值

### v1 路径（1064B, Android 4.2+）

1. **P-224 曲线 + 压缩公钥**：证书 SPKI 从 89B 降到 50B
2. **SHA-1 摘要**（比 SHA-256 短 12B/条目）
3. **手工构造 E.EC**：跳过 openssl cms 的冗余包装
4. **zopfli 压缩 + 手工 ZIP**：去掉 Python zipfile 的额外字段

### RSA 512 路径（1111B, Android 1.0+）

用 RSA 512 + SHA-1 替代 EC，兼容 2008 年的 Android 1.0。

## Android 16 封堵的 ApkGolf 技巧

ApkGolf 的 678B（2017 年 Android 8）用了这些技巧，Android 16 全部拒绝：

| 技巧 | 原本省 | 现状 |
|---|---|---|
| 24B StringPool 头 | 4B | 拒绝解析 |
| 假 OID 1.2 | 14B | 拒绝加载证书 |
| 空证书签名 03 01 00 | 71B | 拒绝验证 |
| 短 UTCTIME (11B) | 4B | 拒绝 |
| 非标准 name (OID 0.1) | 10B | 拒绝 |
| P-192/P-224 曲线 | 48B | v2 拒绝 |
| 压缩公钥 | 26B | v2 拒绝 |

## 文件说明

- `apksigner-mod.jar` — 改过的 apksigner（去 4K 对齐）
- `AndroidManifest.xml` — 156B 极简 manifest
- `v2u_mini.apk` — 未签名的 223B 骨架（v2 用）
- `fixed_huff.py` — 固定 Huffman 编码器（实验性，有 bug 未使用）
联系方式:asxz1954@outlook.com

## 结论

**768B / 1064B / 1111B 是 Android 16 时代的实际物理极限。**

与 ApkGolf 的 678B 差 90B — 全部是 Android 16 新增的验证器限制，不是技术差距。

要突破只有三条路：
1. 手写 C 二进制打包器，逐字节控制 ASN.1 和 PKCS#7
2. 修改 Android 系统验证器
3. 等 Android 出更宽松的签名方案
4. 使用C程序一直试出更短的签名，目前最短66b
# Minimal APK Research Log

## Final Deliverables

| Directory | File | Size | Android Support |
|---|---|---|---|
| Android1.0+/ | final_1111.apk | 1111B | Android 1.0 - 16 |
| Android4.2+/ | final_1064.apk | 1064B | Android 4.2 - 16 |
| Android7.0+/ | final_776.apk | 768B | Android 7.0 - 16 |

All three verified installable on Android 16.

## Core Breakthroughs

### v2 Path (768B)

1. **Patched apksig source to remove 4K alignment**: Modified bytecode constants `4096 → 1` in `ApkSigner.class` and `ApkSigningBlockUtils.class`, eliminating 3955B of padding.
2. **Reverse-engineered apksig's chunked_sha256 algorithm**:
   - 3 separate data sources (local data + central directory + EOCD)
   - Each chunk = `SHA256(0xa5 + u32(len) + data)`
   - Final = `SHA256(0x5a + u32(3) + chunk0 + chunk1 + chunk2)`
3. **Hand-built v2 signature block**: bypassed apksig's PKCS#7 wrapping to produce a more compact structure.
4. **Certificate slimming**: stripped version / SKI / AKI / BasicConstraints, set serial to 1.
5. **Signature length hunting**: ECDSA signature length is random (68/69/70/71/72B); repeatedly re-sign to hit the minimum.

### v1 Path (1064B, Android 4.2+)

1. **P-224 curve + compressed public key**: cert SPKI reduced from 89B to 50B.
2. **SHA-1 digests** (12B shorter per entry than SHA-256).
3. **Hand-built E.EC**: skipped openssl cms's redundant wrapping.
4. **zopfli compression + manual ZIP packing**: removed Python zipfile's extra fields.

### RSA 512 Path (1111B, Android 1.0+)

Used RSA 512 + SHA-1 instead of EC to support Android 1.0 from 2008.

## ApkGolf Techniques Blocked by Android 16

ApkGolf achieved 678B in 2017 (Android 8). Android 16 rejects every one of those techniques:

| Technique | Savings | Status |
|---|---|---|
| 24-byte StringPool header | 4B | Rejected (parse fail) |
| Fake OID 1.2 | 14B | Rejected (cert load fail) |
| Empty cert signature `03 01 00` | 71B | Rejected (verify fail) |
| Short UTCTIME (11B) | 4B | Rejected |
| Non-standard name (OID 0.1) | 10B | Rejected |
| P-192 / P-224 curve | 48B | Rejected (v2 path) |
| Compressed public key | 26B | Rejected (v2 path) |

## File Manifest

- `apksigner-mod.jar` — patched apksigner (no 4K alignment)
- `AndroidManifest.xml` — 156B minimal manifest
- `v2u_mini.apk` — unsigned 223B skeleton (for v2 path)
- `fixed_huff.py` — fixed Huffman encoder (experimental, has bugs, unused)

## Conclusion

**768B / 1064B / 1111B are the physical limits on Android 16.**

Difference from ApkGolf's 678B is 90B — entirely due to Android 16's stricter verifier, not a technical gap.

Only three paths to go smaller:
1. Hand-write a C binary packer with byte-level control over ASN.1 and PKCS#7.
2. Modify Android's verifier.
3. Wait for a more lenient signing scheme in future Android versions.
4. I have been trying to find shorter signatures using the C program, and currently the shortest is 65b
Contact Information:asxz1954@outlook.com